# JMLR style file

LaTeX style file for the Journal of Machine Learning Research
